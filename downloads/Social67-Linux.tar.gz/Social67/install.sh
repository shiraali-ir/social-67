#!/bin/sh
# نصب میانبر Social 67 در منوی برنامه‌ها
D="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/social67.desktop" <<EOT
[Desktop Entry]
Type=Application
Name=Social 67
Exec=$D/Social67
Path=$D
Icon=$D/icon.png
Categories=Network;
EOT
chmod +x "$D/Social67"
echo "Social 67 installed."
